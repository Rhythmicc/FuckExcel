import openpyxl
from openpyxl.styles import Font, Alignment
import os

user_root = os.path.expanduser('~')
